//
//  HelloWorldFramework.h
//  HelloWorldFramework
//
//  Created by Ricardo on 03/11/22.
//

#import <Foundation/Foundation.h>

//! Project version number for HelloWorldFramework.
FOUNDATION_EXPORT double HelloWorldFrameworkVersionNumber;

//! Project version string for HelloWorldFramework.
FOUNDATION_EXPORT const unsigned char HelloWorldFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloWorldFramework/PublicHeader.h>


