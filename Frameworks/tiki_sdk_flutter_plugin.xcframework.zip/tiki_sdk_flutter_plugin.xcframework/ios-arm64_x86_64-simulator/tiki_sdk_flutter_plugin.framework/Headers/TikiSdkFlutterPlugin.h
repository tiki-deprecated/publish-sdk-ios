#import <Flutter/Flutter.h>

@interface TikiSdkFlutterPlugin : NSObject<FlutterPlugin>
@end
